# Step 9 - Build the CMS!

Run the server to see what the CMS looks like!


*Everything is broken...*

Fix it!

Your job is to write a new server and router. You'll serve the public assets and handle any embedded requests in the `index.html`.


Good luck! Remember, work with your team and chat with your mentor!

---

## [**Next step >>>**](step10.md)
